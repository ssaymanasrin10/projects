import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
public class SignUp extends Frame implements ActionListener, WindowListener{
	private TextField tf;
	private TextField tf2;
	private TextField tf3;
	
	public SignUp(){
		super("Signup Window");
        ImageIcon ic=new ImageIcon(getClass().getResource("pic.png")); 
		this.setIconImage(ic.getImage());
		Label l=new Label("User Id");
		Label l2=new Label("User Name");
		Label l3=new Label("Password");
		
		tf=new TextField(28);
		tf2=new TextField(28);
		tf3=new TextField(28);
		
		Button b=new Button("Signup");
		Button b1=new Button("Back");
		Button b2=new Button ("Delete Password");
		setBackground(Color.GRAY);
		add(l);add(tf);
		add(l2);add(tf2);
		add(l3);add(tf3);
		
		add(b);add(b1);add(b2);
		setLayout(new FlowLayout());
		setBackground(Color.GRAY);
		
		//SignUp sign=new SignUp();
		//sign.setVisible(true);
		setSize(800,400);
		//setLocation(400,200);
		b.addActionListener(this);
		b1.addActionListener(this);
		b2.addActionListener(this);
		addWindowListener(this);
		//setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		System.out.println("Button Pressed");
		String s=ae.getActionCommand();
		DataAccess da=new DataAccess();
		System.out.println(s);
		if(s.equals("Signup")){
		
				if(tf.getText().length()!=0 && tf2.getText().length()!=0 && tf3.getText().length()!=0){
				String q="insert into CHECKER (id,name,pass) values ('"+tf.getText()+"','"+tf2.getText()+"','"+tf3.getText()+"')";
				try{
				da.updateDB(q);
				}
				catch(Exception ex)
			{
				System.out.println("value same");
				//JOptionPane.showMessageDialog(this,"Same Value");
			
				
			}
				
				}	
			
			
		
		else{
			JOptionPane.showMessageDialog(this,"Text Field error");  
		}
		}
		else if(s.equals("Back")){
			Login log = new Login();
			this.setVisible(false);
			log.setVisible(true);
	}
	else if(s.equals("Delete Password"))
	{	DeletePass d=new DeletePass();
		d.setVisible(true);
		this.setVisible(false);
	
	}

}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowClosing(WindowEvent e){
		//this.setVisible(false);
		System.exit(0);
	}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
}