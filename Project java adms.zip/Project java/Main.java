
public class Main{
	public static void main(String s[]){

		Login l=new Login();
		l.setVisible(true);
		
		
		}          
	
				}
