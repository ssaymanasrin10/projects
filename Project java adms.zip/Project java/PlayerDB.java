//package collectionsample;
/*public class PlayerDB{
	private int id;
	private String name;
	private int salary;
	
	
	public PlayerDB(){
        System.out.println("no arg called");
	}
	public PlayerDB(int id,String n,int a){
        this.id=id;
		this.name=n;
		this.salary=a;
		
		
		System.out.println("Player is created");
	}
	public void setInfo(int id,String n,int a){
		id=i;
		name=n;
		salary=a;
		
	}
	public void setID(int i){	id=i;}
	public void setName(String n){	name=n;}
	public void setSalary(int a){ salary=a;}

	
	public String getName(){return name;}
	public int getID(){return id;}
	public int getSalary(){return salary;}
	
	
	public void print(){
            System.out.println("\nDetails of "+name);
            System.out.println("ID : "+id+", Name :"+name+", Salary: "+salary+");
	}
	public String getDetails(){
		return "ID : "+id+", Name :"+name+", Salary: "+salary;
	}
	public String toString(){
		return "ID : "+id+", Name :"+name+", Salary: "+salary ;
	}
}*/