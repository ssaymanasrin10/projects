import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;

class DeletePass extends Frame implements WindowListener,ActionListener{

	
        private TextField id;

	private Button back;

        private Button drop;

	public DeletePass(){
		super("Delete Password");
		
                ImageIcon ic=new ImageIcon(getClass().getResource("pic.png")); 
		this.setIconImage(ic.getImage());            
                id = new TextField(10);

                Label i = new Label("User Id: ");


             
		back=new Button("Back");
                add(i);
                add(id);

           
		add(back);
                drop = new Button("delete");
                add(drop);
		setSize(800,400);
		setLayout(new FlowLayout());
		addWindowListener(this);
                drop.addActionListener(this);
		back.addActionListener(this);

	}
	public void windowClosing(WindowEvent we){
        System.out.println("Window is closing");
		System.exit(0);
	}
	public void actionPerformed(ActionEvent e){
                DataAccess da=new DataAccess();
		String s=e.getActionCommand();


		if(s.equals("Back")){
			SignUp sign =new SignUp();
			sign.setVisible(true);
		this.setVisible(false);
		}
                else if(s.equals("delete")){
					
                        String q = "DELETE FROM CHECKER WHERE id = '"+id.getText()+"'";
			da.updateDB(q);
                        
			System.out.println(q);                   
                }
		


	}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}

}