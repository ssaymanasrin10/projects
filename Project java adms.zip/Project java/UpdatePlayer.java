import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
public class UpdatePlayer extends Frame implements ActionListener, WindowListener{
	//private TextField tf;
	private TextField tf2;
	//private TextField tf3;
		private TextField tf4;
	//private TextField tf5;
	//private TextField tf6;
		//private TextField tf7;
	//private TextField tf8;
	//private TextField tf9;
	
	public UpdatePlayer(){
		super("UpdatePlayer");
        ImageIcon ic=new ImageIcon(getClass().getResource("pic.png")); 
		this.setIconImage(ic.getImage());
		//Label l=new Label("Id");
		Label l2=new Label("Name");
//Label l3=new Label("Salary");
		Label l4=new Label("age");
				//Label l5=new Label("position");
		//Label l6=new Label("nationality");
		//Label l7=new Label("height");
				//Label l8=new Label("foot");
		//Label l9=new Label("club");
		
		
		//tf=new TextField(28);
		tf2=new TextField(28);
		//tf3=new TextField(28);
		tf4=new TextField(28);
		//tf5=new TextField(28);
		//tf6=new TextField(28);
		//tf7=new TextField(28);
		//tf8=new TextField(28);
		//tf9=new TextField(28);		
		Button b=new Button("Update");
		Button b1=new Button("Back");
		
		setBackground(Color.GRAY);
		//add(l);add(tf);
		add(l2);add(tf2);
		//add(l3);add(tf3);
		add(l4);add(tf4);
		//add(l5);add(tf5);
		//add(l6);add(tf6);
		
		//add(l7);add(tf7);
		//add(l8);add(tf8);
		//add(l9);add(tf9);
		
		
		add(b);add(b1);
		setLayout(new FlowLayout());
		setBackground(Color.GRAY);
		
		//SignUp sign=new SignUp();
		//sign.setVisible(true);
		setSize(800,400);
		//setLocation(400,200);
		b.addActionListener(this);
		b1.addActionListener(this);
		//b2.addActionListener(this);
		addWindowListener(this);
		//setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		System.out.println("Button Pressed");
		String s=ae.getActionCommand();
		DataAccess da=new DataAccess();
		System.out.println(s);
		
		if(s.equals("Update")){
			//try{
				if(tf2.getText().length()!=0 && tf4.getText().length()!=0 ){
				String q = "update player SET age = ('"+tf4.getText()+"') where name= ('"+tf2.getText()+"')";//(id,name,age,salary,position,nationality,height,foot,club) values ('"+tf.getText()+"','"+tf2.getText()+"','"+tf3.getText()+"','"+tf4.getText()+"','"+tf5.getText()+"','"+tf6.getText()+"','"+tf7.getText()+"','"+tf8.getText()+"','"+tf9.getText()+"')";
				try{
				da.updateDB(q);
				//System.out.println(q);
				}
				catch(Exception ex)
					{
				System.out.println("value same");
					}
				//JOptionPane.showMessageDialog(this,"Same Value");
			
				
				
				}	
			
			
		
		else{
			JOptionPane.showMessageDialog(this,"Text Field error");  
		}
		}
		
		else if(s.equals("Back")){
			Player p = new Player();
			this.setVisible(false);
			p.setVisible(true);
	}


}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowClosing(WindowEvent e){
		//this.setVisible(false);
		System.exit(0);
	}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
}