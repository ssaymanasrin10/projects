import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
public class Login extends Frame implements ActionListener, WindowListener{
	TextField username;
	TextField password;
	int i=0;
	//private LoginConnect loginconnect  ;
	public Login(){
		super("Java Login Window");
        ImageIcon ic=new ImageIcon(getClass().getResource("pic.png")); 
		this.setIconImage(ic.getImage());
		//loginconnect=l;
		Label l=new Label("User Name");
		Label l2=new Label("Password");
		username=new TextField(28);
		password=new TextField(28);
		password.setEchoChar('@');
		Button b=new Button("Login");
		Button b2=new Button("Cancel");
		Button b3=new Button("Signup");
		setBackground(Color.GRAY);
		add(l);add(username);
		add(l2);add(password);
		add(b);add(b2);add(b3);
		b.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		addWindowListener(this);
		setLayout(new FlowLayout());
		setSize(280,400);
		
		//setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		String s=ae.getActionCommand();
		if(s.equals("Login")){
           if(username.getText().length()!=0 && password.getText().length()!=0){
		   DataAccess da=new DataAccess();
		   
		   
			String typedName=username.getText();
			String typedPass=password.getText();
			//String q="select name,pass from LoginConnect";
			String q="SELECT * FROM CHECKER ";
			ResultSet rs=null;
			//System.out.println(q);		
			try{
				rs=da.getData ("select * from CHECKER ");
				System.out.println(q);
				while(rs.next()){
					String n = rs.getString("NAME");
					String p= rs.getString("PASS");
					if(n.equals(typedName) && p.equals(typedPass)){
						System.out.println("Correct Cred.");
						HomePage home = new HomePage();
						home.setVisible(true);
						this.setVisible(false);
						i++;
						break;
					}
				}
				if(i==0){
					JOptionPane.showMessageDialog(this,"login error");
				}
			}
			catch(Exception ex){
				JOptionPane.showMessageDialog(this,"DB Error");
				//ex.printStackTrace();
			}
		   }
		   else{
			 JOptionPane.showMessageDialog(this,"Text Field error");  
		   }
		
		}
		else if(s.equals("Cancel")){
			//loginconnect.setVisible(true);
			this.setVisible(false);
		}
		else if(s.equals("Signup")){
			SignUp sign = new SignUp();
		sign.setVisible(true);
		this.setVisible(false);}

		
	}
		public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowClosing(WindowEvent e){
		//this.setVisible(false);
		System.exit(0);
	}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
}