import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;

class HomePage extends Frame implements ActionListener, WindowListener{
	
	
	private Staff staff;
	private Player player;
	

	
	public HomePage(){
		super("Homepage");
		        ImageIcon ic=new ImageIcon(getClass().getResource("pic.png")); 
		this.setIconImage(ic.getImage());
		
		staff=new Staff();
		player=new Player();
		//coach =new coach();
		
	
		
		Button staff=new Button("Staff");
		Button player=new Button("Player");
		Button logOut = new Button("Log Out");


		add(staff);add(player); add(logOut);
		setBackground(Color.GRAY);
		staff.addActionListener(this);
		
		player.addActionListener(this);
		
		logOut.addActionListener(this);
	
		addWindowListener(this);
		setLayout(new FlowLayout());
		setSize(800,400);
		
	
	}
	public void actionPerformed(ActionEvent e){
		String s=e.getActionCommand();
		

		
		if(s.equals("Staff")){
			staff.setVisible(true);
			this.setVisible(false);
		}
		else if(s.equals("Player")){
			player.setVisible(true);
			this.setVisible(false);
		}
		
		
		else if(s.equals("Log Out")){
                Login log = new Login();
                log.setVisible(true);
                this.setVisible(false);
		}
		
	}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowClosing(WindowEvent e){
		//this.setVisible(false);
		System.exit(0);
	}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
}