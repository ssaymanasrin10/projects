import java.awt.Frame;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
class Player extends Frame implements ActionListener, WindowListener{ 
	private TextArea ta;
	public Player(){
		super("Player");
        ImageIcon ic=new ImageIcon(getClass().getResource("pic.png")); 
        this.setIconImage(ic.getImage());
		this.setIconImage(ic.getImage());
		
		Button b = new Button("Back");
	    Button logOut = new Button("Log Out");
	    Button show = new Button("Show");
		Button addplayer = new Button("AddPlayer");
		Button updateplayer = new Button("UpdatePlayer");
		Button deleteplayer = new Button("DeletePlayer");
		
		
		add(b);add(logOut);add(show);add(addplayer);add(updateplayer);add(deleteplayer);
		b.setBounds(120,120,80,30);
		logOut.setBounds(300,120,80,30);
		ta=new TextArea(8,35);
		add(ta);
		logOut.addActionListener(this);
		setBackground(Color.GRAY);
		setLayout(new FlowLayout());
		setSize(670,400);
		setLocation(800,200);
		addWindowListener(this);
		show.addActionListener(this);
		b.addActionListener(this);
		addplayer.addActionListener(this);
		updateplayer.addActionListener(this);
		deleteplayer.addActionListener(this);

		
	}
	public void actionPerformed(ActionEvent ae){
		String s=ae.getActionCommand();
			if(s.equals("Back")){
			HomePage h12 = new HomePage();
			this.setVisible(false);
			h12.setVisible(true);
	}
	else if(s.equals("Log Out")){
                Login log = new Login();
                log.setVisible(true);
                this.setVisible(false);
		}
			else if(s.equals("Show")){
					try{
				DataAccess da=new DataAccess();
				ResultSet rs=null;
				rs=da.getData("select * from player");
				while(rs.next()){
					String str=rs.getInt("id")+":"+rs.getString("name")+":"+rs.getString("salary");
					ta.append(str+"\n");
				}
			}catch(Exception ex){ex.printStackTrace();}
		}
		else if(s.equals("AddPlayer")){
			AddPlayer add=new AddPlayer();
			add.setVisible(true);
		this.setVisible(false);}
		
		else if(s.equals("UpdatePlayer")){
			UpdatePlayer update=new UpdatePlayer();
			update.setVisible(true);
		this.setVisible(false);}
		
		else if(s.equals("DeletePlayer")){
			DeletePlayer delete=new DeletePlayer();
			delete.setVisible(true);
		this.setVisible(false);}
		
	}
    	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowClosing(WindowEvent e){
		//this.setVisible(false);
		System.exit(0);
	}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
}