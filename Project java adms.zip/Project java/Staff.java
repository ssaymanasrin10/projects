import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
class Staff extends Frame implements ActionListener, WindowListener{
	//private TextField tf;
	//private TextField tf2;
	public Staff(){
		super("Staff");
		        ImageIcon ic=new ImageIcon(getClass().getResource("pic.png")); 
		this.setIconImage(ic.getImage());
		 Label l=new Label("Name  phone number  salary    age");
		Label l2=new Label("raju    01788880        $40000      35");
		Button b = new Button("Back");
		Button logOut = new Button("Log Out");
		add(l);
		add(l2);
		add(b);
		add(logOut);
		l.setBounds(120,40,280,30);
		l2.setBounds(120,80,600,30);
		b.setBounds(120,120,80,30);
		logOut.setBounds(300,120,80,30);
		setLayout(null);
		setSize(600,400);
		setLocation(800,200);
		addWindowListener(this);
		logOut.addActionListener(this);
		setBackground(Color.GRAY);

		b.addActionListener(this);
		//setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		String s=ae.getActionCommand();
				if(s.equals("Back")){
			HomePage h12 = new HomePage();
			this.setVisible(false);
			h12.setVisible(true);
	}
	else if(s.equals("Log Out")){
                Login log = new Login();
                log.setVisible(true);
                this.setVisible(false);
		}		
	}
   	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowClosing(WindowEvent e){
		//this.setVisible(false);
		System.exit(0);
	}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}

}