import java.awt.*;
class Coach extends Frame{
	private  Button back;
	private Button logout;
	//private TextField tf2;
	HomePage h=new HomePage();
	public Coach(){
		super("Coach");
		Label l=new Label("Name    phone number     salary      age");
		Label l2=new Label("raju    01788880          $40000       35");
		Label l3=new Label("shawn    01712342         $300000     30");
		Label l4=new Label("rumi    017983524         $123400       50");
		add(l);
		add(l2);
		add(l3);
		add(l4);
		 back=new Button("Back");
		 logout = new Button("Log Out");
		add(back);
		add(logout);
		
		setLayout(null);
		setSize(400,600);
		setLocation(800,400);
		setLayout(new FlowLayout());
		
	/*	l.setBounds(120,40,250,30);
		l2.setBounds(120,80,600,30);
		l3.setBounds(120,120,600,30);
		l4.setBounds(120,160,600,30);
		back.setBounds(120,200,50,20);*/
		//logout.setBounds(210,250,50,20);
		//back.addActionListener(this);
		//logout.addActionListener(this);
		
		
		
	}

		
	

}